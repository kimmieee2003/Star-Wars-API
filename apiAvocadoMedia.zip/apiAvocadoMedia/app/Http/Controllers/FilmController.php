<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use GuzzleHttp\Psr7\Response;
use Illuminate\Support\Facades\DB;

class FilmController extends Controller
{
    public function index()
    {
        $client = new Client();
        $api_response = $client->get('https://swapi.dev/api/films/');
        $stream = $api_response->getBody();
        $contents = json_decode($stream);
        return view('swapi_views/swapi', compact('contents'));
    }

    public function film($id)
    {
        $client = new Client();
        $api_response = $client->get("https://swapi.dev/api/films/$id");
        $stream = $api_response->getBody();
        $contents = json_decode($stream);
        return view('swapi_views/film', compact('contents'));
    }

    public function filmsearch()
    {
        $client = new Client();
        $data = request()->all();
        $id = $data['filmid'];
        $api_response = $client->get("https://swapi.dev/api/films/$id");
        $stream = $api_response->getBody();
        $contents = json_decode($stream);
        return view('swapi_views/film', compact('contents'));
    }

    public function filmfavorites()
    {
        $client = new Client();
        $data = request()->all();
        $id = $data['filmid'];
        $title = $data['filmtitle'];
        $episode = $data['filmid'];
        if ($id == 1 || $id == 2 || $id == 3) {
            $id = $id + 3;
        } elseif ($id == 4 || $id == 5 || $id == 6) {
            $id = $id - 3;
        }
        DB::insert("insert into films (film_id, title, episode_id) values (?, ?, ?)", [$id, $title, $episode]);
        $api_response = $client->get('https://swapi.dev/api/films/');
        $stream = $api_response->getBody();
        $contents = json_decode($stream);
        return view('swapi_views/swapi', compact('contents'));
    }

    public function removefavorites()
    {
        $client = new Client();
        $data = request()->all();
        $id = $data['filmid'];
        DB::delete("delete from films where film_id = $id");
        $api_response = $client->get('https://swapi.dev/api/films/');
        $stream = $api_response->getBody();
        $contents = json_decode($stream);
        return view('swapi_views/swapi', compact('contents'));
    }

    public function removefavoritesfromfavorites()
    {
        $data = request()->all();
        $id = $data['filmid'];
        DB::delete("delete from films where film_id = $id");
        $query = DB::select("select * from films");
        $contents = [];
        foreach ($query as $film) {
            $filmid = $film->film_id;
            $client = new Client();
            $api_response = $client->get("https://swapi.dev/api/films/$filmid");
            $stream = $api_response->getBody();
            $filmdata = json_decode($stream);
            array_push($contents, $filmdata);
        }
        return view('swapi_views/favorite', compact('contents'));
    }

    public function seeAllFavorites()
    {
        $query = DB::select("select * from films");
        $contents = [];
        foreach ($query as $film) {
            $id = $film->film_id;
            $client = new Client();
            $api_response = $client->get("https://swapi.dev/api/films/$id");
            $stream = $api_response->getBody();
            $filmdata = json_decode($stream);
            array_push($contents, $filmdata);
        }
        return view('swapi_views/favorite', compact('contents'));
    }
}